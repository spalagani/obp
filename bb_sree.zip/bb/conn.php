<?php


	$servername = "localhost";
$username = "sreecorp_root";
$password = "test123";
$db="sreecorp_bb";
$serverurl = "http://sreecorp.com/bb/";


$conn = new mysqli($servername, $username, $password, $db);
date_default_timezone_set("Asia/Kolkata");
?>